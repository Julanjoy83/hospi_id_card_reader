// =======================
// id_scanner_screen.dart
// =======================

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';

import '../services/ocr_service.dart';

class IdScannerScreen extends StatefulWidget {
  final WebSocket? socket;
  final bool isConnected;
  final VoidCallback? onReturnToSplash;

  const IdScannerScreen({
    super.key,
    this.socket,
    this.isConnected = false,
    this.onReturnToSplash,
  });

  @override
  State<IdScannerScreen> createState() => _IdScannerScreenState();
}

class _IdScannerScreenState extends State<IdScannerScreen>
    with TickerProviderStateMixin {
  // ====== Services ======
  final OCRService _ocrService = OCRService();
  final AudioPlayer _player = AudioPlayer();
  final FlutterTts _tts = FlutterTts();
  final MethodChannel _nfcChannel = const MethodChannel('com.hospi_id_scan.nfc');

  // ====== Réseau ======
  WebSocket? _socket;
  bool _isConnected = false;
  bool _ownsSocket = false;

  // Découverte
  String _receiverIP = "0.0.0.0";
  int _receiverPort = 3000;
  static const int _discoveryPort = 3001;
  static const String _wantedMac = "DC:62:94:38:3C:C0";
  static final InternetAddress _mcastAddr = InternetAddress('239.255.255.250');
  RawDatagramSocket? _mcastListenSocket;

  // ====== OCR / UI ======
  File? _selectedImage;
  Map<String, String>? _extracted;
  bool _isProcessing = false;
  bool _isSpeaking = false;
  bool _isWritingNfc = false;

  // ====== Animations ======
  late final AnimationController _fadeController;
  late final AnimationController _slideController;
  late final AnimationController _nfcController;
  late final AnimationController _pulseController;

  // ====== Inactivité ======
  Timer? _inactivityTimer;

  // ====== Palette moderne ======
  static const Color primaryBlue = Color(0xFF1E88E5);
  static const Color darkBlue = Color(0xFF1565C0);
  static const Color accentOrange = Color(0xFFFF6B35);
  static const Color successGreen = Color(0xFF10B981);
  static const Color warningOrange = Color(0xFFF59E0B);
  static const Color errorRed = Color(0xFFEF4444);
  static const Color bgGrey = Color(0xFFF8FAFC);
  static const Color cardWhite = Colors.white;
  static const Color textDark = Color(0xFF1E293B);
  static const Color textLight = Color(0xFF64748B);

  bool get _connected =>
      (_socket?.readyState == WebSocket.open) || _isConnected || widget.isConnected;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initTts();
    _resetInactivityTimer();

    if (widget.socket != null) {
      _socket = widget.socket;
      _isConnected = widget.isConnected || (_socket?.readyState == WebSocket.open);
      _ownsSocket = false;
    } else {
      _ownsSocket = true;
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await _speak("Placez votre carte d'identité sur l'espace prévu pour, ensuite appuyez sur SCAN.");
        await _startMulticastListener();
        await _runDiscoveryAndConnect();
        if (!_isConnected && _receiverIP != "0.0.0.0") {
          await _connectWebSocket();
        }
      });
    }

    if (widget.socket != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _speak("Placez votre carte d'identité sur l'espace prévu pour, ensuite appuyez sur SCAN.");
      });
    }
  }

  @override
  void dispose() {
    _inactivityTimer?.cancel();
    _tts.stop();
    _player.dispose();
    if (_ownsSocket) _socket?.close();
    _mcastListenSocket?.close();
    _fadeController.dispose();
    _slideController.dispose();
    _nfcController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _resetInactivityTimer() {
    _inactivityTimer?.cancel();
    _inactivityTimer = Timer(const Duration(minutes: 5), () {
      widget.onReturnToSplash?.call();
    });
  }

  void _onUserActivity() => _resetInactivityTimer();

  Future<void> _initTts() async {
    await _tts.setLanguage("fr-FR");
    await _tts.setSpeechRate(0.8);
    await _tts.setVolume(0.9);
    await _tts.setPitch(1.0);
    _tts.setStartHandler(() => setState(() => _isSpeaking = true));
    _tts.setCompletionHandler(() => setState(() => _isSpeaking = false));
    _tts.setErrorHandler((_) => setState(() => _isSpeaking = false));
  }

  Future<void> _speak(String text) async {
    if (_isSpeaking) await _tts.stop();
    try {
      await _tts.speak(text);
    } catch (_) {
      setState(() => _isSpeaking = false);
    }
  }

  void _setupAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _nfcController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  // ==================== RÉSEAU ====================
  Future<String?> _getLocalIPv4() async {
    final ifaces = await NetworkInterface.list(
      type: InternetAddressType.IPv4,
      includeLoopback: false,
    );
    for (final iface in ifaces) {
      for (final a in iface.addresses) {
        if (a.type == InternetAddressType.IPv4 && !a.address.startsWith('127.')) {
          return a.address;
        }
      }
    }
    return null;
  }

  InternetAddress _guessBroadcast(String localIp) {
    final parts = localIp.split('.');
    if (parts.length == 4) {
      return InternetAddress('${parts[0]}.${parts[1]}.${parts[2]}.255');
    }
    return InternetAddress('255.255.255.255');
  }

  Future<void> _startMulticastListener() async {
    try {
      _mcastListenSocket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, _discoveryPort);
      _mcastListenSocket!.joinMulticast(_mcastAddr);
      _mcastListenSocket!.listen((evt) {
        if (evt == RawSocketEvent.read) {
          final d = _mcastListenSocket!.receive();
          if (d == null) return;
          try {
            final payload = utf8.decode(d.data);
            final parsed = jsonDecode(payload);
            if (parsed is Map && parsed['action'] == 'LOUNA_HEARTBEAT') {
              final mac = parsed['mac']?.toString();
              final ip = parsed['ip']?.toString() ?? d.address.address;
              final int port = parsed['port'] is int
                  ? parsed['port']
                  : int.tryParse(parsed['port']?.toString() ?? '3000') ?? 3000;

              if (mac != null && (_wantedMac.isEmpty || mac == _wantedMac)) {
                final changed = (_receiverIP != ip || _receiverPort != port);
                if (changed) {
                  setState(() {
                    _receiverIP = ip;
                    _receiverPort = port;
                  });
                  if (!_isConnected && _ownsSocket) _connectWebSocket();
                }
              }
            }
          } catch (_) {}
        }
      });
    } catch (e) {
      debugPrint("❌ Multicast listener KO: $e");
    }
  }

  Future<Map<String, Map<String, dynamic>>> _discoverReceivers({
    int timeoutSeconds = 3,
    int repeats = 3,
  }) async {
    final results = <String, Map<String, dynamic>>{};
    RawDatagramSocket? socket;

    try {
      socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      socket.broadcastEnabled = true;

      final localIp = await _getLocalIPv4();
      final bcastNet = localIp != null ? _guessBroadcast(localIp) : InternetAddress('255.255.255.255');
      final bcastAll = InternetAddress('255.255.255.255');

      final reqBytes = utf8.encode(jsonEncode({
        'action': 'DISCOVER_LOUNA',
        'time': DateTime.now().toIso8601String(),
      }));

      for (int i = 0; i < repeats; i++) {
        socket.send(reqBytes, bcastNet, _discoveryPort);
        socket.send(reqBytes, bcastAll, _discoveryPort);
        await Future.delayed(const Duration(milliseconds: 120));
      }

      final completer = Completer<void>();
      final timer = Timer(Duration(seconds: timeoutSeconds), () {
        if (!completer.isCompleted) completer.complete();
      });

      socket.listen((evt) {
        if (evt == RawSocketEvent.read) {
          final d = socket!.receive();
          if (d == null) return;
          try {
            final payload = utf8.decode(d.data);
            final parsed = jsonDecode(payload);
            final mac = parsed['mac']?.toString();
            final ip = parsed['ip']?.toString() ?? d.address.address;
            final int port = parsed['port'] is int
                ? parsed['port']
                : int.tryParse(parsed['port']?.toString() ?? '3000') ?? 3000;

            if (mac != null && mac.isNotEmpty) {
              results[mac] = {'ip': ip, 'port': port, 'raw': parsed};
            }
          } catch (_) {}
        }
      });

      await completer.future;
      timer.cancel();
    } catch (e) {
      debugPrint("❌ discoverReceivers error: $e");
    } finally {
      socket?.close();
    }

    return results;
  }

  Future<void> _runDiscoveryAndConnect() async {
    final discovered = await _discoverReceivers(timeoutSeconds: 3, repeats: 3);
    if (discovered.isEmpty) return;

    String selectedIp = discovered.values.first['ip'];
    int selectedPort = discovered.values.first['port'];

    if (_wantedMac.isNotEmpty && discovered.containsKey(_wantedMac)) {
      selectedIp = discovered[_wantedMac]!['ip'];
      selectedPort = discovered[_wantedMac]!['port'];
    }

    setState(() {
      _receiverIP = selectedIp;
      _receiverPort = selectedPort;
    });
    if (_ownsSocket) await _connectWebSocket();
  }

  Future<void> _connectWebSocket() async {
    if (!_ownsSocket) return;
    if (_receiverIP == "0.0.0.0" || _receiverIP.trim().isEmpty) return;

    for (;;) {
      try {
        final uri = 'ws://$_receiverIP:$_receiverPort';
        _socket = await WebSocket.connect(uri);
        _isConnected = true;
        if (!mounted) return;
        setState(() {});

        _socket!.listen(
              (msg) {
            _onUserActivity();
            final data = jsonDecode(msg);
            if (data is Map && data["action"] == "start_nfc") {
              _writeToNfc();
            }
          },
          onDone: () {
            _isConnected = false;
            if (!mounted) return;
            setState(() {});
            _reconnect();
          },
          onError: (_) {
            _isConnected = false;
            if (!mounted) return;
            setState(() {});
            _reconnect();
          },
        );
        break;
      } catch (_) {
        await Future.delayed(const Duration(seconds: 2));
        if (_receiverIP == "0.0.0.0") return;
      }
    }
  }

  void _reconnect() {
    if (_ownsSocket && mounted) _connectWebSocket();
  }

  void _sendToReceiver(Map<String, String> data) {
    if (_socket == null || _socket!.readyState != WebSocket.open) return;
    _socket!.add(jsonEncode(data));
  }

  // ==================== NFC ====================
  Future<void> _writeToNfc() async {
    _onUserActivity();
    if (_extracted == null) return;
    setState(() => _isWritingNfc = true);
    _nfcController.forward();
    await _speak("Approchez la carte fournie du capteur orange.");
    final json = jsonEncode(_extracted);
    try {
      await _nfcChannel.invokeMethod('writeTag', {'text': json});
      if (!mounted) return;
      setState(() => _isWritingNfc = false);
      _nfcController.reverse();
      _showSnackBar("✅ Carte de chambre obtenue !", successGreen);
      await _speak("Votre carte est prête. Bienvenue à l'hôtel !");
    } on PlatformException catch (e) {
      if (!mounted) return;
      setState(() => _isWritingNfc = false);
      _nfcController.reverse();
      _showSnackBar("❌ Erreur NFC : ${e.message}", errorRed);
      await _speak("Erreur, veuillez réessayer.");
    }
  }

  void _showSnackBar(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ==================== OCR ====================
  Future<void> _pickImage(ImageSource src) async {
    _onUserActivity();
    final picker = ImagePicker();
    final img = await picker.pickImage(
      source: src,
      imageQuality: 85,
      maxWidth: 1920,
      maxHeight: 1080,
    );
    if (img == null) return;

    setState(() {
      _selectedImage = File(img.path);
      _extracted = null;
      _isProcessing = true;
    });

    _fadeController.forward();
    _slideController.forward();

    try {
      final raw = await _ocrService.scanTextFromImage(_selectedImage!);

      final hasValidData = raw['nom'] != 'INCONNU' &&
          raw['nom'] != 'ERREUR' &&
          (raw['prenoms'] != 'INCONNU' || raw['idNumber'] != 'INCONNU');

      if (!hasValidData) {
        if (!mounted) return;
        setState(() => _isProcessing = false);
        _showSnackBar("❌ Aucune donnée extraite. Réessayez avec une meilleure photo.", errorRed);
        await _speak("Je n'ai pas pu lire le document. Réessayez avec une photo plus nette.");
        return;
      }

      final normalized = {
        'name': (raw['nom'] ?? raw['nomUsage'] ?? '').toString(),
        'surname': (raw['prenoms'] ?? raw['givenNames'] ?? '').toString(),
        'idNumber': (raw['idNumber'] ?? '').toString(),
        'nationality': (raw['nationalite'] ?? raw['nationality'] ?? '').toString(),
        ...raw.map((k, v) => MapEntry(k.toString(), v?.toString() ?? '')),
      };

      if (!mounted) return;
      setState(() {
        _extracted = normalized;
        _isProcessing = false;
      });

      _sendToReceiver(normalized);
      await _speak("Scan terminé. Vérifiez les informations, puis obtenez votre carte.");
    } catch (e) {
      if (!mounted) return;
      setState(() => _isProcessing = false);
      _showSnackBar("❌ Erreur de traitement : $e", errorRed);
      await _speak("Erreur de traitement, veuillez réessayer.");
    }
  }

  // ==================== HELPERS UI ====================
  InputDecoration _modernInput(String label, String hint, IconData icon) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: primaryBlue.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: primaryBlue, size: 20),
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
        borderSide: BorderSide(color: primaryBlue, width: 2),
      ),
      filled: true,
      fillColor: Colors.grey.shade50,
    );
  }

  Map<String, String> _formatForDisplay(Map<String, String> raw) {
    return {
      'Nom': raw['nom'] ?? raw['nomUsage'] ?? raw['name'] ?? 'INCONNU',
      'Prénoms': raw['prenoms'] ?? raw['givenNames'] ?? raw['surname'] ?? 'INCONNU',
      'N° Document': raw['idNumber'] ?? 'INCONNU',
      'Nationalité': raw['nationalite'] ?? raw['nationality'] ?? 'Inconnue',
    };
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _onUserActivity,
      onPanDown: (_) => _onUserActivity(),
      child: Scaffold(
        backgroundColor: bgGrey,
        appBar: _buildAppBar(),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildInstructionCard(),
                    const SizedBox(height: 16),
                    _buildActionButtons(),
                    if (_selectedImage != null) ...[
                      const SizedBox(height: 20),
                      _buildImagePreview(),
                    ],
                    if (_isProcessing) ...[
                      const SizedBox(height: 20),
                      _buildProcessingCard(),
                    ],
                    if (_extracted != null && !_isProcessing) ...[
                      const SizedBox(height: 20),
                      _buildExtractedCard(),
                    ],
                    const SizedBox(height: 100), // Espace pour le bouton flottant
                  ],
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: _extracted != null && !_isProcessing
            ? _buildFloatingButton()
            : null,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardWhite.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.document_scanner, size: 20),
          ),
          const SizedBox(width: 12),
          const Text(
            "HOSPI SMART",
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5),
          ),
        ],
      ),
      centerTitle: true,
      backgroundColor: primaryBlue,
      foregroundColor: cardWhite,
      elevation: 0,
      leading: widget.onReturnToSplash == null
          ? null
          : IconButton(
        icon: const Icon(Icons.arrow_back_ios_new, size: 20),
        tooltip: "Retour",
        onPressed: () => widget.onReturnToSplash?.call(),
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 16),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: _connected
                ? successGreen.withOpacity(0.2)
                : errorRed.withOpacity(0.2),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _connected
                  ? successGreen.withOpacity(0.5)
                  : errorRed.withOpacity(0.5),
              width: 1.5,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _connected ? successGreen : errorRed,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: (_connected ? successGreen : errorRed).withOpacity(0.5),
                      blurRadius: 4,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _connected ? "Connecté" : "Hors ligne",
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInstructionCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [primaryBlue, darkBlue],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardWhite.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.smart_toy, color: cardWhite, size: 28),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "LOUNA",
                      style: TextStyle(
                        color: cardWhite,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      "Votre assistante intelligente",
                      style: TextStyle(
                        color: cardWhite,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardWhite.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: cardWhite.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: const Text(
              "Placez votre carte d'identité sur l'espace prévu, puis appuyez sur SCAN pour commencer l'analyse.",
              style: TextStyle(
                color: cardWhite,
                fontSize: 15,
                height: 1.5,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            onPressed: () => _speak(
              "Placez votre carte d'identité sur l'espace prévu pour, ensuite appuyez sur SCAN.",
            ),
            icon: const Icon(Icons.volume_up, size: 20, color: cardWhite),
            label: const Text(
              "Écouter l'instruction",
              style: TextStyle(
                color: cardWhite,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: TextButton.styleFrom(
              backgroundColor: cardWhite.withOpacity(0.2),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardWhite,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Choisissez une option",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: textDark,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _buildGalleryButton()),
              const SizedBox(width: 12),
              Expanded(child: _buildScanButton()),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGalleryButton() {
    return ElevatedButton(
      onPressed: () => _pickImage(ImageSource.gallery),
      style: ElevatedButton.styleFrom(
        backgroundColor: warningOrange,
        foregroundColor: cardWhite,
        padding: const EdgeInsets.symmetric(vertical: 20),
        elevation: 4,
        shadowColor: warningOrange.withOpacity(0.4),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: cardWhite.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.photo_library_rounded, size: 28),
          ),
          const SizedBox(height: 10),
          const Text(
            "Galerie",
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 15,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScanButton() {
    return ElevatedButton(
      onPressed: () => _pickImage(ImageSource.camera),
      style: ElevatedButton.styleFrom(
        backgroundColor: accentOrange,
        foregroundColor: cardWhite,
        padding: const EdgeInsets.symmetric(vertical: 20),
        elevation: 6,
        shadowColor: accentOrange.withOpacity(0.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: cardWhite.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.document_scanner, size: 28),
          ),
          const SizedBox(height: 10),
          const Text(
            "SCAN",
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 15,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImagePreview() {
    return FadeTransition(
      opacity: _fadeController,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.2),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                Image.file(
                  _selectedImage!,
                  height: 220,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: successGreen,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: successGreen.withOpacity(0.4),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.check_circle, color: cardWhite, size: 18),
                        SizedBox(width: 6),
                        Text(
                          "Photo chargée",
                          style: TextStyle(
                            color: cardWhite,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProcessingCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: cardWhite,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 80,
                height: 80,
                child: CircularProgressIndicator(
                  strokeWidth: 5,
                  valueColor: AlwaysStoppedAnimation<Color>(primaryBlue),
                ),
              ),
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: primaryBlue.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.analytics,
                  color: primaryBlue,
                  size: 30,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Text(
            "Analyse en cours...",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: textDark,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "LOUNA traite votre document avec précision",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: textLight,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExtractedCard() {
    if (_extracted == null) return const SizedBox.shrink();
    final display = _formatForDisplay(_extracted!);
    final hasErrors = display.values.any(
          (v) => v.contains('INCONNU') || v.contains('ERREUR') || v.contains('Inconnue'),
    );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardWhite,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: successGreen.withOpacity(0.3), width: 2),
        boxShadow: [
          BoxShadow(
            color: successGreen.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: successGreen.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.verified_user,
                  color: successGreen,
                  size: 26,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Données extraites",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: textDark,
                      ),
                    ),
                    Text(
                      "Vérifiez les informations",
                      style: TextStyle(
                        fontSize: 12,
                        color: textLight,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          ...display.entries.map((e) => _buildDataField(e.key, e.value)),
          if (hasErrors) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: warningOrange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: warningOrange.withOpacity(0.3),
                  width: 1.5,
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline, color: warningOrange, size: 22),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      "Certaines données sont manquantes. Modifiez-les ou refaites un SCAN.",
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: textDark,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 16),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: _editExtractedData,
              icon: const Icon(Icons.edit, size: 20),
              label: const Text(
                "Modifier les informations",
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              style: TextButton.styleFrom(
                foregroundColor: primaryBlue,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                backgroundColor: primaryBlue.withOpacity(0.1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDataField(String label, String value) {
    final isError = value.contains('INCONNU') ||
        value.contains('ERREUR') ||
        value.contains('Inconnue');

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isError
            ? warningOrange.withOpacity(0.08)
            : Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isError
              ? warningOrange.withOpacity(0.3)
              : Colors.grey.shade200,
          width: 1.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 14,
                color: textDark,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: isError ? warningOrange : textDark,
              ),
            ),
          ),
          if (!isError)
            const Icon(Icons.check_circle, color: successGreen, size: 20),
        ],
      ),
    );
  }

  Widget _buildFloatingButton() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      width: double.infinity,
      height: 64,
      child: ElevatedButton(
        onPressed: _isWritingNfc ? null : _writeToNfc,
        style: ElevatedButton.styleFrom(
          backgroundColor: accentOrange,
          foregroundColor: cardWhite,
          elevation: 8,
          shadowColor: accentOrange.withOpacity(0.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          disabledBackgroundColor: Colors.grey.shade400,
        ),
        child: _isWritingNfc
            ? const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                color: cardWhite,
                strokeWidth: 3,
              ),
            ),
            SizedBox(width: 16),
            Text(
              "Gravure en cours...",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
              ),
            ),
          ],
        )
            : Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: cardWhite.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.nfc, size: 24),
            ),
            const SizedBox(width: 12),
            const Text(
              "OBTENIR LA CARTE",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== ÉDITION MANUELLE ====================
  Future<void> _editExtractedData() async {
    _onUserActivity();
    if (_extracted == null) return;

    String _cleanName(String s) {
      final t = s.trim().replaceAll(RegExp(r'\s+'), ' ');
      return t
          .split(' ')
          .map((w) => w.isEmpty
          ? w
          : w[0].toUpperCase() + w.substring(1).toLowerCase())
          .join(' ');
    }

    final nomCtl = TextEditingController(
      text: _extracted!['nom'] ??
          _extracted!['nomUsage'] ??
          _extracted!['name'] ??
          '',
    );
    final prenomsCtl = TextEditingController(
      text: _extracted!['prenoms'] ??
          _extracted!['givenNames'] ??
          _extracted!['surname'] ??
          '',
    );
    final idNumberCtl = TextEditingController(
      text: _extracted!['idNumber'] ?? '',
    );
    final natCtl = TextEditingController(
      text: _extracted!['nationalite'] ??
          _extracted!['nationality'] ??
          '',
    );

    await showDialog(
      context: context,
      builder: (ctx) {
        String? errorMsg;
        return StatefulBuilder(
          builder: (ctx, setSt) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: primaryBlue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.edit, color: primaryBlue),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "Corriger les informations",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nomCtl,
                      textCapitalization: TextCapitalization.words,
                      decoration: _modernInput("Nom", "ex: DUPONT", Icons.person_outline),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: prenomsCtl,
                      textCapitalization: TextCapitalization.words,
                      decoration: _modernInput("Prénoms", "ex: Jean Pierre", Icons.badge),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: idNumberCtl,
                      textCapitalization: TextCapitalization.characters,
                      decoration: _modernInput("N° Document", "ex: X123456", Icons.confirmation_number),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: natCtl,
                      textCapitalization: TextCapitalization.words,
                      decoration: _modernInput("Nationalité", "ex: Française", Icons.public),
                    ),
                    if (errorMsg != null) ...[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: errorRed.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: errorRed.withOpacity(0.3),
                          ),
                        ),
                        child: Text(
                          errorMsg!,
                          style: const TextStyle(
                            color: errorRed,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text(
                    "Annuler",
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.check, size: 20),
                  label: const Text(
                    "Valider",
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryBlue,
                    foregroundColor: cardWhite,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () {
                    final newNom = _cleanName(nomCtl.text);
                    final newPrenoms = _cleanName(prenomsCtl.text);
                    final newId = idNumberCtl.text.trim();
                    final newNat = _cleanName(natCtl.text);

                    if (newNom.isEmpty || (newPrenoms.isEmpty && newId.isEmpty)) {
                      setSt(() => errorMsg =
                      "Nom obligatoire, et au moins Prénoms ou N° Document.");
                      return;
                    }

                    setState(() {
                      // FR pour affichage
                      _extracted!['nom'] = newNom;
                      _extracted!['nomUsage'] = newNom;
                      _extracted!['prenoms'] = newPrenoms;
                      _extracted!['givenNames'] = newPrenoms;
                      _extracted!['idNumber'] = newId;
                      _extracted!['nationalite'] = newNat;

                      // Normalisé pour récepteur
                      _extracted!['name'] = newNom;
                      _extracted!['surname'] = newPrenoms;
                      _extracted!['nationality'] = newNat;
                    });

                    _sendToReceiver(_extracted!);

                    Navigator.pop(ctx);
                    _showSnackBar("✅ Informations mises à jour", successGreen);
                    _speak("Informations mises à jour.");
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }
}
