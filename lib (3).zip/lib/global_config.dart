class GlobalConfig {
  static const String openAIApiKey =
      "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";
}// TODO Implement this library.