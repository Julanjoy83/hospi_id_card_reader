class GlobalConfig {
  static const String openAIApiKey =
      "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";
}